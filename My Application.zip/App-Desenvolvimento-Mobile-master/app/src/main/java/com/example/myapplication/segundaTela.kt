package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class segundaTela : AppCompatActivity() {

    private lateinit var buttonVoltar: Button
    private lateinit var buttonProxima: Button
    private lateinit var nota1: EditText
    private lateinit var nota2: EditText
    private lateinit var nota3: EditText
    private lateinit var nota4: EditText
    private lateinit var calcularButton: Button
    private lateinit var resultadoTextView: TextView
    private lateinit var imagemReprovado: ImageView
    private lateinit var imagemProvaSub: ImageView
    private lateinit var imagemAprovado: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        buttonVoltar = findViewById(R.id.buttonVoltar)
        buttonProxima = findViewById(R.id.buttonProxima)
        nota1 = findViewById(R.id.nota1)
        nota2 = findViewById(R.id.nota2)
        nota3 = findViewById(R.id.nota3)
        nota4 = findViewById(R.id.nota4)
        calcularButton = findViewById(R.id.calcularButton)
        resultadoTextView = findViewById(R.id.resultadoTextView)
        imagemReprovado = findViewById(R.id.imagemReprovado)
        imagemProvaSub = findViewById(R.id.imagemProvaSub)
        imagemAprovado = findViewById(R.id.imagemAprovado)

        buttonVoltar.setOnClickListener {
            val intent = Intent(this, primeiraTela::class.java)
            startActivity(intent)
            finish()
        }

        buttonProxima.setOnClickListener {
            val intent = Intent(this, terceiraTela::class.java)
            startActivity(intent)
        }

        calcularButton.setOnClickListener {
            val nota1Value = nota1.text.toString().toDoubleOrNull() ?: 0.0
            val nota2Value = nota2.text.toString().toDoubleOrNull() ?: 0.0
            val nota3Value = nota3.text.toString().toDoubleOrNull() ?: 0.0
            val nota4Value = nota4.text.toString().toDoubleOrNull() ?: 0.0

            val media = (nota1Value + nota2Value + nota3Value + nota4Value) / 4
            val resultado = verificarAprovacao(media)
            resultadoTextView.text = "Média: $media - $resultado"

            imagemReprovado.visibility = View.GONE
            imagemProvaSub.visibility = View.GONE
            imagemAprovado.visibility = View.GONE

            when (resultado) {
                "Reprovado" -> imagemReprovado.visibility = View.VISIBLE
                "Prova sub" -> imagemProvaSub.visibility = View.VISIBLE
                "Aprovado" -> imagemAprovado.visibility = View.VISIBLE
            }
        }
    }

    fun verificarAprovacao(media: Double): String {
        return when {
            media < 4 -> "Reprovado"
            media in 4.0..5.9 -> "Prova sub"
            else -> "Aprovado"
        }
    }
}
